- HTML documentation is generated from .rst files with Sphinx

$ sphinx-build -b html ./sphinx/rst OutDir/sphinx/html
Or use the target doc in the cmake build system
$ make doc

Sphinx setup:
Please follow the http://sphinx-doc.org/latest/install.html guide.

