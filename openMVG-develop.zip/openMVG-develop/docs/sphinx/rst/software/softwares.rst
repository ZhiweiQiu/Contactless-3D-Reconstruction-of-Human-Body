############################
openMVG softwares & tools
############################
  
.. toctree::
  :maxdepth: 1
  
  SfM/SfM.rst
  ui/SfM/control_points_registration/GCP.rst
  localization/localization.rst
  Geodesy/geodesy.rst
  MVS/MVS.rst
  colorHarmonization/color.rst



