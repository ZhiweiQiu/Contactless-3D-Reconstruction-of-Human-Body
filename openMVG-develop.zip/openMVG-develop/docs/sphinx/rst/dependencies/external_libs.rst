############################
dependencies
############################

OpenMVG library uses the git submodule idea to make its repository lighter.

Here are the libraries used through the submodule concept:


.. toctree::
   :maxdepth: 1

   ./glfw.rst
   ./openExif.rst
   ./osi_clp.rst

